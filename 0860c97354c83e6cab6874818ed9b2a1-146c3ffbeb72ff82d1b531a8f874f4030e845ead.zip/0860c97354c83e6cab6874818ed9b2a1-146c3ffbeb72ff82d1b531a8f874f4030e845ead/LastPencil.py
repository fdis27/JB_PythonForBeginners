import random

print('How many pencils would you like to use:')
while True:
    try:
        total_pencils = int(input())
        if total_pencils <= 0:
            print('The number of pencils should be positive')
        else:
            break
    except ValueError:
        print('The number of pencils should be numeric')

name = (input("Who will be the first (John, Jack):"))
while name not in ('John', 'Jack'):
    print('Choose between John and Jack')
    name = input()

print(total_pencils * '|')
print(name + "'s", "turn:")

while total_pencils > 0:
    try:
        if name == 'John':
            pencils_turn = int(input())
            while pencils_turn not in (1, 2, 3):
                print("Possible values: '1', '2' or '3'")
                pencils_turn = int(input())
            while pencils_turn > total_pencils:
                print('Too many pencils were taken')
                pencils_turn = int(input())
        elif name == 'Jack':
            if total_pencils == 1:
                pencils_turn = 1
            else:
                if total_pencils % 4 == 0:
                    pencils_turn = 3
                elif total_pencils % 4 == 3:
                    pencils_turn = 2
                elif total_pencils % 4 == 2:
                    pencils_turn = 1
                else:
                    pencils_turn = (random.randint(1, 3))
            print(pencils_turn)
        total_pencils -= pencils_turn
        print(total_pencils * '|')
        name = 'John' if name == 'Jack' else 'Jack'
        if total_pencils > 0:
            print(name + 's', 'turn:')
        else:
            print(name, 'won!')
            break
    except ValueError:
        print("Possible values: '1', '2' or '3'")
